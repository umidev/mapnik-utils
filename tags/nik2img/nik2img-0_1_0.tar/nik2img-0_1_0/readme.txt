
Nik2img.py 0.1.0
Copyright 2008, Dane Springmeyer (dbsgeo [ -a- ] gmail.com)
======================================

A command line utility to take a mapnik xml file as input and output an image.

To run this program::
   Make sure you have Mapnik installed
   Download, install, untar, make executable, and place in your path like:

$ wget http://mapnik-utils.googlecode.com/svn/tags/nik2img/nik2img-0_1_0.tar
$ tar xvf nik2img-0_1_0.tar
$ cd nik2img-0_1_0
$ sudo cp nik2img.py /usr/local/bin/
$ sudo chmod +x /usr/local/bin/nik2img.py

Or just fetch the script from: http://mapnik-utils.googlecode.com/svn/tags/nik2img/nik2img-0_1_0/nik2img.py
Then launch a python interpreter in the same directory and run:

$ python nik2img.py -h

For more info see: http://code.google.com/p/mapnik-utils/wiki/Nik2Img


