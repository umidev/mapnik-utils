
Nik2img.py 0.1.0
================

A command line utility to take a mapnik xml file as input and output an image.

To install, untar, make executable, and place in your path like:

$ tar xvf nik2img-0_1_0.tar
$ cd nik2img-0_1_0
$ chmod +x nik2img.py
$ cp nik2img.py /usr/local/bin/

Then to use, make sure you have Mapnik installed, then do:

$ ./nik2img.py -h

For more info see: http://code.google.com/p/mapnik-utils/wiki/Nik2Img


